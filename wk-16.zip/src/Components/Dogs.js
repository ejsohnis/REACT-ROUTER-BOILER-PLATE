import React, { useEffect, useState } from 'react'
import { useHistory, useRouteMatch, Switch, Route } from 'react-router-dom';
import { getAnimals, deleteAnimal } from '../Services/animal'
import DogTableRow from './DogTableRow';
import DogUpdate from './DogUpdate';

function Dogs() {
    const history = useHistory();
    const match = useRouteMatch()
    const handleClick = (id) => history.push(`/dogsummary/${id}`);
    const [animals, setAnimals] = useState([])

    useEffect(() => {
        getAnimals()
            .then((response) => {
                setAnimals([...response])
            })
    }, [])

    const handleDelete = (id) => {
        deleteAnimal(id)
            .then(res => {
                getAnimals()
                    .then((response) => {
                        setAnimals([...response])
                    })
                if (res.ok) {
                    return res.json();
                }
                // handle error
            }).catch(error => {
                console.log(error);

            })
    }


    return (
        <div className="container">
            <h2>List of Dogs</h2>
            <table className="table table-success table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Breed</th>
                        <th scope="col">Origin</th>
                        <th scope="col">Size</th>
                        <th scope="col">Weight</th>
                        <th scope="col">Age</th>
                        <th scope="col">Show Dog</th>
                        <th scope="col">Update</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {

                        animals.length > 0 && animals.map((animal, idx) => <DogTableRow
                            idx={idx}
                            key={animal.id}
                            animal={animal}
                            updateDog={`${match.path}/dog/${animal.id}`}
                            deleteDog={() => handleDelete(animal.id)}
                            onClick={() => handleClick(animal.id)} />
                        )
                    }
                </tbody>
            </table>
            <Switch>
                <Route
                    path={`${match.path}/dog/:dogId`}
                    render={(props) => <DogUpdate
                        currentDogs={animals}
                        setCurrentDogs={setAnimals}
                    />}
                />
            </Switch>
        </div>

    )
}



export default Dogs