import React from 'react'

function AnimalImage() {
    return (
        <div>AnimalImage</div>
    )
}

export default AnimalImage
