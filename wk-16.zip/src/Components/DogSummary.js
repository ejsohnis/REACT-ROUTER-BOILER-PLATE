import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { getAnimal } from '../Services/animal'
import Dogs from './Dogs';
import DogTableRow from './DogTableRow';

const emptyAnimal = {
    name: "",
    breed: "",
    image: "",
    origin: "",
    size: "",
    weight: "",
    age: ""
}

// useParam gets the id from the url which is the id number of the animal
function DogSummary() {
    const { id } = useParams();
    // animal represents a variable; setAnimal represent a function which updates the varibale, and useState creates the variable and the function.
    const [animal, setAnimal] = useState(emptyAnimal)
    // useEffect will execute only once because of the empty Array, after the ui render
    useEffect(() => {
        getAnimal(id)
            .then((response) => {
                console.log(response);
                setAnimal({ ...response })
            })
    }, [])


    return (
        <div className="container p-4">
            <div className="card" style={{ width: '18rem' }}>
                <div className="card-body">
                    <h5 className="card-title">Name {animal.name}</h5>
                    <h6 className="card-subtitle mb-2 text-muted">Breed {animal.breed}</h6>
                    <h6 className="card-subtitle mb-2 text-muted">Origin {animal.origin}</h6>
                    <h6 className="card-subtitle mb-2 text-muted">Size {animal.size}</h6>
                    <h6 className="card-subtitle mb-2 text-muted">Weight {animal.weight}</h6>
                    <h6 className="card-subtitle mb-2 text-muted">Age {animal.age}</h6>



                </div>
            </div>


        </div>
    )
}

export default DogSummary