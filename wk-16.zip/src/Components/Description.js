import React from 'react'

export default function Description() {
    return (
        <div className="container">
            <div className="row">
                <div className="col-6">
                    <h4> Description:</h4>
                    <p>
                        Dogs are the most popular animals, they are affectionate, inteligent and are full with energy. they are known as loyal to humans. People like to keep them as pets and as protection. Dogs are mammal and have a great sense of smell and hearing. Various breed are very small and some are large and bears a large weight. People had various breeds for various purpuses.
                    </p>
                </div>
            </div>
        </div>

    )
}
