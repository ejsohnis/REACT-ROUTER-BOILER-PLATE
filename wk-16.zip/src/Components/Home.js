import React from 'react'
import Description from './Description';
//the name of the function is the name of the component
function Home() {



    return (
        <div>
            <Description />
        </div>
    )
}


export default Home