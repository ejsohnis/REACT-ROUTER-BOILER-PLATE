import React from 'react';
import './App.css';
import Home from "./Components/Home";
import DogSummary from './Components/DogSummary';
import DogCreation from './Components/DogCreation';
import AnimalNavbar from './Components/AnimalNavbar';

import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Dogs from './Components/Dogs';

export default function App() {
  return (
    <Router>
      <div>
        {/* AnimalNavbar contain navigation html, and navigate between components dogs, dogsummary and dogcreation */}
        <AnimalNavbar />

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Switch>

          <Route path="/dogs">
            <Dogs />
          </Route>

          <Route path="/dogsummary/:id">
            <DogSummary />
          </Route>

          <Route path="/dogcreation">
            <DogCreation />
          </Route>

          <Route path="/">
            <Home />
          </Route>

        </Switch>
      </div>
    </Router>
  );

}
