<!-- 
    Copyright (c) 2023 Promineo Tech
    Author:  Promineo Tech Academic Team
    Subject: React Router Boiler Plate
  ------------------------------------------->
  
# Web App Design with React Router Week 16 Coding Assignment

## Instructions 

1. run ```npm install```
2. run ```npm start```




